package com.example.appdoctruyen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.appdoctruyen.Interface.LayAnhVe;
import com.example.appdoctruyen.apitruyentranh.ApiAnhTruyen;
import com.example.appdoctruyen.apitruyentranh.ApiChapTruyen;
import com.example.appdoctruyen.object.ChapTruyen;
import com.example.appdoctruyen.object.TruyenTranh;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class DocTruyenActivity extends AppCompatActivity implements LayAnhVe {
ImageView imgAnh;
ArrayList<String> arrUrlAnh;
int soTrang, soTrangDangDoc;
String idChap;
ChapTruyen chapTruyen;
TextView txvsotrangdoc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_truyen);
        init();
        anhxa();
        setUp();
        setClick();
        new ApiAnhTruyen(this,idChap).execute();
    }
    private  void init(){
        Bundle b = getIntent().getBundleExtra("data");
        idChap = b.getString("idChap");
    }
    private  void anhxa(){
        imgAnh = findViewById(R.id.imgAnh);
        txvsotrangdoc = findViewById(R.id.txvsotrangdoc);
    };
    private  void setUp(){

    };
    private  void setClick(){};
    public void left(View view) {
        docTheoTrang( -1);
    }

    public void right(View view) {
        docTheoTrang(1);
    }
    private void docTheoTrang(int i ){
        soTrangDangDoc = soTrangDangDoc+i;
        if(soTrangDangDoc == 0){
            soTrangDangDoc=1;
        }
        if(soTrangDangDoc>soTrang){
            soTrangDangDoc =soTrang;
        }
        txvsotrangdoc.setText(soTrangDangDoc +"/"+soTrang );
        Glide.with(this).load(arrUrlAnh.get(soTrangDangDoc-1)).into(imgAnh); // doc link anh
    }

    @Override
    public void batDau() {
        Toast.makeText(this,"Đang lấy truyện về",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void ketThuc(String data) {
        arrUrlAnh = new ArrayList<>();

        try {
            JSONArray arr = new JSONArray(data);
            for (int i=0;i<arr.length();i++){
                arrUrlAnh.add(arr.getString(i));
            }
            soTrangDangDoc = 1 ;
            soTrang= arrUrlAnh.size();
            docTheoTrang(0);
        }catch (JSONException e ){
            e.printStackTrace();

        }


    }

    @Override
    public void biLoi() {

    }
}