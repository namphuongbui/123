package com.example.appdoctruyen.Interface;

public interface LayAnhVe {
    void  batDau();
    void  ketThuc(String data);
    void  biLoi();
}
