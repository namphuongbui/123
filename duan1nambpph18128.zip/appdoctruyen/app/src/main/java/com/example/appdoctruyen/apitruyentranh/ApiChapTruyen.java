package com.example.appdoctruyen.apitruyentranh;

import android.os.AsyncTask;

import com.example.appdoctruyen.Interface.LayChapVe;
import com.example.appdoctruyen.Interface.LayTruyenVe;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.ResponseBody;

import java.io.IOException;

public class ApiChapTruyen extends AsyncTask<Void,Void,Void> {
String data;
LayChapVe layChapVe;
String idTruyen;

    public ApiChapTruyen(LayChapVe layChapVe, String idTruyen) {
        this.layChapVe = layChapVe;
        this.layChapVe.batDau();
        this.idTruyen = idTruyen;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("https://truyentranh1997.000webhostapp.com/laychaptranh.php?id="+idTruyen)
                //.url("http://api.myjson.com/bins/xvr2p")
                .build();
        data= null;
        try {
            Response response = client.newCall(request).execute();
            ResponseBody body = response.body();
            data = body.string();
        }catch (IOException e ){
           data= null;
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void unused) {
        if (data == null){
            this.layChapVe.biLoi();
        }else {
            this.layChapVe.ketThuc(data);
        }
    }
}
