package com.example.appdoctruyen.Interface;

public interface LayTruyenVe {
    void  batDau();
    void  ketThuc(String data);
    void  biLoi();
}
