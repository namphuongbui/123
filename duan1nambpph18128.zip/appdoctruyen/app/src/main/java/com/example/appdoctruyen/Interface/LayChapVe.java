package com.example.appdoctruyen.Interface;

public interface LayChapVe {
    void  batDau();
    void  ketThuc(String data);
    void  biLoi();
}
